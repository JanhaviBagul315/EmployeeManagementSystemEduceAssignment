﻿using EmployeeMgmtSystem.BusinessLogicLayer.Interface;
using EmployeeMgmtSystem.DomainLayer.Entities;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Data;

namespace EmployeeMgmtSystem.DataAccessLayer.Services
{
    public class EmployeeServices : IEmployeeServices
    {
        private readonly ILogger<EmployeeServices> _logger;
        private readonly string _connectionString;
        public EmployeeServices(ILogger<EmployeeServices> logger,IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("Default");
            _logger = logger;
        }

        public int AddEmployee(Employee employee)
        {
            try
            {
                _logger.LogInformation("AddEmployee method started");

                SqlConnection conn = new SqlConnection(_connectionString);
                conn.Open();

                SqlCommand cmd = new SqlCommand("CreateEmployees", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FullName", employee.FullName);
                cmd.Parameters.AddWithValue("@Email", employee.Email);
                cmd.Parameters.AddWithValue("@State", employee.State);
                cmd.Parameters.AddWithValue("@City", employee.City);
                cmd.Parameters.AddWithValue("@DateOfJoining", employee.DateOfJoining);
                cmd.Parameters.AddWithValue("@IsActive", employee.IsActive);
                cmd.Parameters.AddWithValue("@CreatedBy", employee.CreatedBy);
                cmd.Parameters.AddWithValue("@CreatedOn", employee.CreatedOn);
                cmd.Parameters.AddWithValue("@UpdatedBy", employee.UpdatedBy);
                cmd.Parameters.AddWithValue("@UpdatedOn", employee.UpdatedOn);

                cmd.ExecuteNonQuery();
                conn.Close();

                _logger.LogInformation("Employee added successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in AddEmployee");
            }

            return 1;
        }

        public int DeleteEmployee(int employeeId)
        {
            try
            {
                _logger.LogInformation("DeleteEmployee started for EmployeeId: {EmployeeId}", employeeId);

                SqlConnection conn = new SqlConnection(_connectionString);
                conn.Open();

                SqlCommand cmd = new SqlCommand("DeleteEmployees", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmployeeId", employeeId);
                cmd.ExecuteNonQuery();

                conn.Close();
                _logger.LogInformation("Employee deleted successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in DeleteEmployee");
            }

            return 1;
        }

        public int EditEmployee(Employee employee)
        {
            try
            {
                _logger.LogInformation("EditEmployee started for EmployeeId: {EmployeeId}", employee.EmployeeId);

                SqlConnection conn = new SqlConnection(_connectionString);
                conn.Open();

                SqlCommand cmd = new SqlCommand("UpdateEmployees", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);
                cmd.Parameters.AddWithValue("@FullName", employee.FullName);
                cmd.Parameters.AddWithValue("@Email", employee.Email);
                cmd.Parameters.AddWithValue("@State", employee.State);
                cmd.Parameters.AddWithValue("@City", employee.City);
                cmd.Parameters.AddWithValue("@DateOfJoining", employee.DateOfJoining);
                cmd.Parameters.AddWithValue("@IsActive", employee.IsActive);
                cmd.Parameters.AddWithValue("@CreatedBy", employee.CreatedBy);
                cmd.Parameters.AddWithValue("@CreatedOn", employee.CreatedOn);
                cmd.Parameters.AddWithValue("@UpdatedBy", employee.UpdatedBy);
                cmd.Parameters.AddWithValue("@UpdatedOn", employee.UpdatedOn);

                cmd.ExecuteNonQuery();
                conn.Close();

                _logger.LogInformation("Employee updated successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in EditEmployee");
            }

            return 1;
        }

        public List<Employee> GetActiveEmployees()
        {
            List<Employee> EmployeesList = new List<Employee>();

            try
            {
                _logger.LogInformation("Fetching active employees");

                SqlConnection conn = new SqlConnection(_connectionString);

                conn.Open();

                SqlCommand cmd = new SqlCommand("GetAllActiveEmployees", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Employee employee = new Employee();
                    employee.EmployeeId = Convert.ToInt32(dr["EmployeeId"]);
                    employee.FullName = Convert.ToString(dr["FullName"]);
                    employee.Email = Convert.ToString(dr["Email"]);
                    employee.State = Convert.ToString(dr["State"]);
                    employee.City = Convert.ToString(dr["City"]);
                    employee.DateOfJoining = Convert.ToDateTime(dr["DateOfJoining"]);
                    employee.IsActive = Convert.ToBoolean(dr["IsActive"]);
                    employee.CreatedBy = Convert.ToInt16(dr["CreatedBy"]);
                    employee.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                    employee.UpdatedBy = Convert.ToInt16(dr["UpdatedBy"]);
                    employee.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);

                    EmployeesList.Add(employee);
                }

                dr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in GetActiveEmployee");
            }

            return EmployeesList;
        }

        public List<City> GetAllCity()
        {
            List<City> CityList = new List<City>();

            try
            {
                _logger.LogInformation("Fetching city list");

                SqlConnection conn = new SqlConnection(_connectionString);

                conn.Open();

                SqlCommand cmd = new SqlCommand("GetAllCities", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    City city = new City();
                    city.CityId = Convert.ToInt32(dr["CityId"]);
                    city.CityName = Convert.ToString(dr["CityName"]);
                    CityList.Add(city);
                }

                dr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in GetAllCity");
            }

            return CityList;
        }

        public List<State> GetAllStates()
        {
            List<State> StateList = new List<State>();

            try
            {
                _logger.LogInformation("Fetching state list");

                SqlConnection conn = new SqlConnection(_connectionString);

                conn.Open();

                SqlCommand cmd = new SqlCommand("GetAllStates", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    State state = new State();
                    state.StateId = Convert.ToInt32(dr["StateId"]);
                    state.StateName = Convert.ToString(dr["StateName"]);
                    StateList.Add(state);
                }

                dr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in GetAllStates");
            }

            return StateList;
        }

        public Employee GetEmployeeById(int employeeId)
        {
            Employee employee = new Employee();

            try
            {
                _logger.LogInformation("Fetching employee by ID: {EmployeeId}", employeeId);

                SqlConnection conn = new SqlConnection(_connectionString);

                conn.Open();

                SqlCommand cmd = new SqlCommand("GetEmployeeById", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmployeeId", employeeId);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    employee.EmployeeId = Convert.ToInt32(dr["EmployeeId"]);
                    employee.FullName = Convert.ToString(dr["FullName"]);
                    employee.Email = Convert.ToString(dr["Email"]);
                    employee.State = Convert.ToString(dr["State"]);
                    employee.City = Convert.ToString(dr["City"]);
                    employee.DateOfJoining = Convert.ToDateTime(dr["DateOfJoining"]);
                    employee.IsActive = Convert.ToBoolean(dr["IsActive"]);
                    employee.CreatedBy = Convert.ToInt16(dr["CreatedBy"]);
                    employee.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                    employee.UpdatedBy = Convert.ToInt16(dr["UpdatedBy"]);
                    employee.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);
                }

                dr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in GetEmployeeById");
            }

            return employee;
        }

        public List<Employee> GetEmployeeList()
        {
            List<Employee> EmployeesList = new List<Employee>();

            try
            {
                _logger.LogInformation("Fetching employee list");

                SqlConnection conn = new SqlConnection(_connectionString);

                conn.Open();

                SqlCommand cmd = new SqlCommand("GetAllEmployees", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Employee employee = new Employee();
                    employee.EmployeeId = Convert.ToInt32(dr["EmployeeId"]);
                    employee.FullName = Convert.ToString(dr["FullName"]);
                    employee.Email = Convert.ToString(dr["Email"]);
                    employee.State = Convert.ToString(dr["State"]);
                    employee.City = Convert.ToString(dr["City"]);
                    employee.DateOfJoining = Convert.ToDateTime(dr["DateOfJoining"]);
                    employee.IsActive = Convert.ToBoolean(dr["IsActive"]);
                    employee.CreatedBy = Convert.ToInt16(dr["CreatedBy"]);
                    employee.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                    employee.UpdatedBy = Convert.ToInt16(dr["UpdatedBy"]);
                    employee.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);

                    EmployeesList.Add(employee);
                }

                dr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in GetEmployeeList");
            }

            return EmployeesList;
        }
    }
}
