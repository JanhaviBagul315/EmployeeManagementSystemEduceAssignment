﻿using EmployeeMgmtSystem.BusinessLogicLayer.Interface;
using EmployeeMgmtSystem.DomainLayer.Entities;
using EmployeeMgmtSystem.UserInterface.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace EmployeeMgmtSystem.UserInterface.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployeeServices _services;
        private readonly ILogger<EmployeeController> _logger;

        public EmployeeController(IEmployeeServices service,ILogger<EmployeeController> logger)
        {
            _services = service;
            _logger = logger;
        }

        public IActionResult Index()
        {
            try
            {
                _logger.LogInformation("Fetching employee list");

                var model = new EmployeesViewModel
                {
                    employees = _services.GetEmployeeList(),
                    employee = new DomainLayer.Entities.Employee(),
                    states = _services.GetAllStates(),
                    city = _services.GetAllCity()
                };

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while loading Index page");
                return View("Error");
            }
        }

        public IActionResult Edit(int id)
        {
            try
            {
                _logger.LogInformation("Editing employee with ID {EmployeeId}", id);

                var model = new EmployeesViewModel
                {
                    employees = _services.GetEmployeeList(),
                    employee = _services.GetEmployeeById(id),
                    states = _services.GetAllStates(),
                    city = _services.GetAllCity()
                };

                return View("Index", model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while editing employee with ID {EmployeeId}", id);
                return View("Error");
            }
        }

        public IActionResult Delete(int id)
        {
            try
            {
                _logger.LogWarning("Deleting employee with ID {EmployeeId}", id);

                _services.DeleteEmployee(id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while deleting employee with ID {EmployeeId}", id);
                return View("Error");
            }
        }

        public IActionResult Details(int id)
        {
            try
            {
                _logger.LogInformation("Fetching details for employee with ID {EmployeeId}", id);

                var data = _services.GetEmployeeById(id);
                return PartialView("_Details", data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while fetching employee details with ID {EmployeeId}", id);
                return StatusCode(500);
            }
        }

        [HttpPost]
        public IActionResult Create(EmployeesViewModel model)
        {
            try
            {
                var data = model.employee;

                if (data.EmployeeId != 0)
                {
                    _logger.LogInformation("Updating employee with ID {EmployeeId}", data.EmployeeId);
                    _services.EditEmployee(data);
                }
                else
                {
                    _logger.LogInformation("Creating new employee");
                    _services.AddEmployee(data);
                }

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while creating/updating employee");
                return View("Error");
            }
        }
    }
}
