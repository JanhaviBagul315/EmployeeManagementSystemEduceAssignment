﻿using EmployeeMgmtSystem.DomainLayer.Entities;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace EmployeeMgmtSystem.UserInterface.Controllers
{
    public class ActiveEmployeesController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;

        public ActiveEmployeesController(
            IHttpClientFactory httpClientFactory,
            IConfiguration configuration)
        {
            _httpClient = httpClientFactory.CreateClient();
            _configuration = configuration;
        }

        public async Task<IActionResult> Index()
        {
            var apiUrl = _configuration["ApiSettings:EmployeeApiUrl"];

            var response = await _httpClient.GetAsync(apiUrl);

            if (!response.IsSuccessStatusCode)
            {
                ViewBag.Error = "Unable to load employee data";
                return View(new List<Employee>());
            }

            var jsonData = await response.Content.ReadAsStringAsync();

            var employees = JsonSerializer.Deserialize<List<Employee>>(
                jsonData,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

            return View(employees);
        }
    }
}
