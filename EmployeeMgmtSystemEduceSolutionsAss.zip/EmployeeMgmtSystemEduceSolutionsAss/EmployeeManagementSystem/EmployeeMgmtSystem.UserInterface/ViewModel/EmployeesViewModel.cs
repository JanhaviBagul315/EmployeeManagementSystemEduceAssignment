﻿using EmployeeMgmtSystem.DomainLayer.Entities;

namespace EmployeeMgmtSystem.UserInterface.ViewModel
{
    public class EmployeesViewModel
    {
        public List<Employee> employees { get; set; }
        public Employee employee { get; set; }
        public List<State> states { get; set; }
        public List<City> city { get; set; }
    }
}
