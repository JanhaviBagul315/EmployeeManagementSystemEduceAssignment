using EmployeeMgmtSystem.BusinessLogicLayer.Interface;
using EmployeeMgmtSystem.DataAccessLayer.Services;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

#region Serilog Configuration
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    .WriteTo.Console()
    .WriteTo.File(
        path: "Logs/log-.txt",
        rollingInterval: RollingInterval.Day)
    .CreateLogger();

builder.Host.UseSerilog();
#endregion

builder.Services.AddControllersWithViews();


builder.Services.AddTransient<IEmployeeServices, EmployeeServices>();
builder.Services.AddHttpClient();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseSerilogRequestLogging();

app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Employee}/{action=Index}/{id?}");

app.Run();
