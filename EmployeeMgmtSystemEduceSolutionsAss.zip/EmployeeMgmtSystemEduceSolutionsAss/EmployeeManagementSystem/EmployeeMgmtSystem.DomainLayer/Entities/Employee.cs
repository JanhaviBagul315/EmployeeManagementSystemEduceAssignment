﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EmployeeMgmtSystem.DomainLayer.Entities
{
    public class Employee : BaseEntities
    {
        public int EmployeeId { get; set; }

        [Required(ErrorMessage = "Full Name is required")]
        [StringLength(20, ErrorMessage = "Full Name cannot exceed 20 characters")]
        public string FullName { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "State is required")]
        public string State { get; set; }

        [Required(ErrorMessage = "City is required")]
        public string City { get; set; }

        [Required(ErrorMessage = "Date of Joining is required")]
        public DateTime DateOfJoining { get; set; }
    }
}
