using EmployeeMgmtSystem.BusinessLogicLayer.Interface;
using EmployeeMgmtSystem.DataAccessLayer.Services;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

#region Serilog Configuration
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    .WriteTo.Console()
    .WriteTo.File(
        path: "Logs/log-.txt",
        rollingInterval: RollingInterval.Day)
    .CreateLogger();
builder.Host.UseSerilog();
#endregion

builder.Services.AddControllers();
builder.Services.AddTransient<IEmployeeServices,EmployeeServices>();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowMVC",
        policy =>
        {
            policy.AllowAnyOrigin()
                  .AllowAnyHeader()
                  .AllowAnyMethod();
        });
});


var app = builder.Build();
app.UseCors("AllowMVC");

app.UseSerilogRequestLogging();

app.UseAuthorization();

app.MapControllers();

app.Run();
