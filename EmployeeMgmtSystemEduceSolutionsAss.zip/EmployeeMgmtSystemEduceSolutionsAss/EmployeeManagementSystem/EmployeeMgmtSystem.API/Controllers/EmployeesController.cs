﻿using EmployeeMgmtSystem.BusinessLogicLayer.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeMgmtSystem.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly IEmployeeServices _services;
        private readonly ILogger<EmployeesController> _logger;

        public EmployeesController(
            IEmployeeServices employees,
            ILogger<EmployeesController> logger)
        {
            _services = employees;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult GetActiveEmployees()
        {
            try
            {
                _logger.LogInformation("Fetching active employee list");

                var employees = _services.GetActiveEmployees();

                return Ok(employees);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,"Error occurred while fetching active employees");

                return StatusCode(
                    StatusCodes.Status500InternalServerError,"An error occurred while processing your request.");
            }
        }
    }
}
