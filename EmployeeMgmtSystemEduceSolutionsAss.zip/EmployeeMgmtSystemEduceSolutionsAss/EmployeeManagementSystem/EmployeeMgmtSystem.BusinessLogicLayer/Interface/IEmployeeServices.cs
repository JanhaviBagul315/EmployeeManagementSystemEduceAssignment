﻿using EmployeeMgmtSystem.DomainLayer.Entities;

namespace EmployeeMgmtSystem.BusinessLogicLayer.Interface
{
    public interface IEmployeeServices
    {
        int AddEmployee(Employee employee);
        int EditEmployee(Employee employee);
        int DeleteEmployee(int employeeId);
        List<Employee> GetEmployeeList();
        Employee GetEmployeeById(int employeeId);
        List<State> GetAllStates();
        List<City> GetAllCity();
        List<Employee> GetActiveEmployees();
    }

}

